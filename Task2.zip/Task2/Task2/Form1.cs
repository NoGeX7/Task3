﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Task2
{
    public partial class Form1 : Form
    {
        private Button[,] buttons = new Button[3, 3];
        private char playerSymbol = 'X';
        private char computerSymbol = 'O';
        private Random random = new Random();

        public Form1()
        {
            InitializeComponent();
            InitializeGame();
        }

        private void InitializeGame()
        {
            this.Text = "Хрестики-Нулики";
            this.ClientSize = new Size(320, 340);

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    buttons[i, j] = new Button();
                    buttons[i, j].Size = new Size(100, 100);
                    buttons[i, j].Location = new Point(j * 100, i * 100);
                    buttons[i, j].Font = new Font(FontFamily.GenericSansSerif, 24, FontStyle.Bold);
                    buttons[i, j].Click += Button_Click;
                    this.Controls.Add(buttons[i, j]);
                }
            }
        }

        private void Button_Click(object sender, EventArgs e)
        {
            Button button = sender as Button;

            if (button.Text == "")
            {
                button.Text = playerSymbol.ToString();
                button.Enabled = false;

                if (CheckWin(playerSymbol))
                {
                    EndGame("Ви перемогли!");
                    return;
                }

                if (IsBoardFull())
                {
                    EndGame("Нічия!");
                    return;
                }

                ComputerMove();
            }
        }

        private void ComputerMove()
        {
            List<Button> emptyButtons = new List<Button>();

            foreach (var btn in buttons)
            {
                if (btn.Text == "")
                    emptyButtons.Add(btn);
            }

            if (emptyButtons.Count > 0)
            {
                Button move = emptyButtons[random.Next(emptyButtons.Count)];
                move.Text = computerSymbol.ToString();
                move.Enabled = false;

                if (CheckWin(computerSymbol))
                {
                    EndGame("Комп'ютер переміг!");
                }
                else if (IsBoardFull())
                {
                    EndGame("Нічия!");
                }
            }
        }

        private bool CheckWin(char symbol)
        {
            // Перевірка рядків та стовпців
            for (int i = 0; i < 3; i++)
            {
                if (buttons[i, 0].Text == symbol.ToString() &&
                    buttons[i, 1].Text == symbol.ToString() &&
                    buttons[i, 2].Text == symbol.ToString())
                    return true;

                if (buttons[0, i].Text == symbol.ToString() &&
                    buttons[1, i].Text == symbol.ToString() &&
                    buttons[2, i].Text == symbol.ToString())
                    return true;
            }

            // Перевірка діагоналей
            if (buttons[0, 0].Text == symbol.ToString() &&
                buttons[1, 1].Text == symbol.ToString() &&
                buttons[2, 2].Text == symbol.ToString())
                return true;

            if (buttons[0, 2].Text == symbol.ToString() &&
                buttons[1, 1].Text == symbol.ToString() &&
                buttons[2, 0].Text == symbol.ToString())
                return true;

            return false;
        }

        private bool IsBoardFull()
        {
            foreach (var btn in buttons)
            {
                if (btn.Text == "")
                    return false;
            }
            return true;
        }

        private void EndGame(string message)
        {
            MessageBox.Show(message, "Гра завершена");
            foreach (var btn in buttons)
            {
                btn.Enabled = false;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
       
        }
    }
}
